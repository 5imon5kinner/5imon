import React, { Component } from 'react'
import { AntDesignOutlined, ReadOutlined } from '@ant-design/icons';

export default class Footer extends Component {
    render() {
        return (
            <div >
                    <div style={{backgroundColor:"#FFFFFF"}}>
                        <div style={{color:'white',textAlign:"center"}}>
                            <h3 style={{fontSize:"2em"}}>NUMERICAL METHODS</h3><br/>
                        </div>
                    </div>
            </div>
        )
    }
}
